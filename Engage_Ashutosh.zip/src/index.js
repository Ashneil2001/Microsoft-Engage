// https://www.kaggle.com/rounakbanik/the-movies-dataset/data
// Exercise: Content-based - Include credits data with crew and cast too
// Exercise: Content-based - Make features weighted based on popularity or actors
// Exercise: Collaborative Filtering - Model-based CF with SVD

import fs from "fs";
import csv from "fast-csv";

import prepareRatings from "./preparation/ratings";
import prepareMovies from "./preparation/movies";
import predictWithLinearRegression from "./strategies/linearRegression";
import predictWithContentBased from "./strategies/contentBased";
import {
  predictWithCfUserBased,
  predictWithCfItemBased,
} from "./strategies/collaborativeFiltering";
import { getMovieIndexByTitle } from "./strategies/common";
import { title } from "process";

let MOVIES_META_DATA = {};
let MOVIES_KEYWORDS = {};
let RATINGS = [];

let ME_USER_ID = 0;

function fromMetaDataFile(row) {
  MOVIES_META_DATA[row.id] = {
    id: row.id,
    adult: row.adult,
    budget: row.budget,
    genres: softEval(row.genres, []),
    homepage: row.homepage,
    language: row.original_language,
    title: row.original_title,
    overview: row.overview,
    popularity: row.popularity,
    studio: softEval(row.production_companies, []),
    release: row.release_date,
    revenue: row.revenue,
    runtime: row.runtime,
    voteAverage: row.vote_average,
    voteCount: row.vote_count,
  };
}

function fromKeywordsFile(row) {
  MOVIES_KEYWORDS[row.id] = {
    keywords: softEval(row.keywords, []),
  };
}

function fromRatingsFile(row) {
  RATINGS.push(row);
}

// ======================================================================================

const express = require("express");
const app = express();
// const path = require("path");

app.use(express.json());

// Prep

let moviesMetaDataPromise = new Promise((resolve) =>
  fs
    .createReadStream("./src/data/movies_metadata.csv")
    .pipe(csv({ headers: true }))
    .on("data", fromMetaDataFile)
    .on("end", () => resolve(MOVIES_META_DATA))
);

let moviesKeywordsPromise = new Promise((resolve) =>
  fs
    .createReadStream("./src/data/keywords.csv")
    .pipe(csv({ headers: true }))
    .on("data", fromKeywordsFile)
    .on("end", () => resolve(MOVIES_KEYWORDS))
);

let ratingsPromise = new Promise((resolve) =>
  fs
    .createReadStream("./src/data/ratings_small.csv")
    .pipe(csv({ headers: true }))
    .on("data", fromRatingsFile)
    .on("end", () => resolve(RATINGS))
);

Promise.all([
  moviesMetaDataPromise,
  moviesKeywordsPromise,
  ratingsPromise,
]).then(init);

function init([moviesMetaData, moviesKeywords, ratings]) {
  const { MOVIES_BY_ID, MOVIES_IN_LIST, X } = prepareMovies(
    moviesMetaData,
    moviesKeywords
  );
  globalThis.X = X;
  globalThis.MOVIES_BY_ID = MOVIES_BY_ID;
  globalThis.MOVIES_IN_LIST = MOVIES_IN_LIST;

  let ME_USER_RATINGS = [
    addUserRating(
      ME_USER_ID,
      "Terminator 3: Rise of the Machines",
      "5.0",
      MOVIES_IN_LIST
    ),
    addUserRating(ME_USER_ID, "Jarhead", "4.0", MOVIES_IN_LIST),
    addUserRating(
      ME_USER_ID,
      "Back to the Future Part II",
      "3.0",
      MOVIES_IN_LIST
    ),
    addUserRating(ME_USER_ID, "Jurassic Park", "4.0", MOVIES_IN_LIST),
    addUserRating(ME_USER_ID, "Reservoir Dogs", "3.0", MOVIES_IN_LIST),
    addUserRating(ME_USER_ID, "Men in Black II", "3.0", MOVIES_IN_LIST),
    addUserRating(ME_USER_ID, "Bad Boys II", "5.0", MOVIES_IN_LIST),
    addUserRating(ME_USER_ID, "Sissi", "1.0", MOVIES_IN_LIST),
    addUserRating(ME_USER_ID, "Titanic", "1.0", MOVIES_IN_LIST),
  ];

  const { ratingsGroupedByUser, ratingsGroupedByMovie } = prepareRatings([
    ...ME_USER_RATINGS,
    ...ratings,
  ]);
  globalThis.ratingsGroupedByUser = ratingsGroupedByUser;
  globalThis.ratingsGroupedByMovie = ratingsGroupedByMovie;
}

app.get("/", (req, res) => {
  res.sendFile("./static/index.html", { root: __dirname });
});

app.get("/getAllMovies", (req, res) => {
  var movies = [];
  for (var key in MOVIES_BY_ID) {
    movies.push(MOVIES_BY_ID[key]["title"]);
  }
  res.json(movies);
});

app.get("/linreg", (req, res) => {
  const meUserRatings = ratingsGroupedByUser[ME_USER_ID];
  const linearRegressionBasedRecommendation = predictWithLinearRegression(
    X,
    MOVIES_IN_LIST,
    meUserRatings
  );
  var response = sliceAndDice(
    linearRegressionBasedRecommendation,
    MOVIES_BY_ID,
    10,
    true
  );
  res.json(response);
});

app.get("/contentBase", (req, res) => {
  const title = "Batman Begins";
  const contentBasedRecommendation = predictWithContentBased(
    X,
    MOVIES_IN_LIST,
    title
  );
  const response = sliceAndDice(
    contentBasedRecommendation,
    MOVIES_BY_ID,
    10,
    true
  );
  res.json(response);
});

app.get("/collaFilteringUser", (req, res) => {
  const cfUserBasedRecommendation = predictWithCfUserBased(
    ratingsGroupedByUser,
    ratingsGroupedByMovie,
    ME_USER_ID
  );
  const reponse = sliceAndDice(
    cfUserBasedRecommendation,
    MOVIES_BY_ID,
    10,
    true
  );
  res.json(reponse);
});

app.get("/collaFilteringItem", (req, res) => {
  const cfItemBasedRecommendation = predictWithCfItemBased(
    ratingsGroupedByUser,
    ratingsGroupedByMovie,
    ME_USER_ID
  );
  const response = sliceAndDice(
    cfItemBasedRecommendation,
    MOVIES_BY_ID,
    10,
    true
  );
  res.json(response);
});

app.listen(3000, () => {
  console.log("server is running on port 3000");
});

export function addUserRating(userId, searchTitle, rating, MOVIES_IN_LIST) {
  const { id, title } = getMovieIndexByTitle(MOVIES_IN_LIST, searchTitle);

  return {
    userId,
    rating,
    movieId: id,
    title,
  };
}

export function sliceAndDice(recommendations, MOVIES_BY_ID, count, onlyTitle) {
  recommendations = recommendations.filter(
    (recommendation) => MOVIES_BY_ID[recommendation.movieId]
  );

  recommendations = onlyTitle
    ? recommendations.map((mr) => ({
        title: MOVIES_BY_ID[mr.movieId].title,
        score: mr.score,
      }))
    : recommendations.map((mr) => ({
        movie: MOVIES_BY_ID[mr.movieId],
        score: mr.score,
      }));

  return recommendations.slice(0, count);
}

export function softEval(string, escape) {
  if (!string) {
    return escape;
  }

  try {
    return eval(string);
  } catch (e) {
    return escape;
  }
}
