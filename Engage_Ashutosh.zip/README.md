# Recommendation System in JavaScript
My name is Ashutosh Pareek
and this is My recommendation Engin, Initially, it will take some time to load, Because of initial setup in the terminal 
then after it works smoothly

## How to Start 
```bash
npm install
npm start
```
